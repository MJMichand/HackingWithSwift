import UIKit

let goodDogs = true
var gameOver = false
let isMultiple = 120.isMultiple(of: 3)

var isAuthenticated = false
print(isAuthenticated)
isAuthenticated = !isAuthenticated
print(isAuthenticated)
isAuthenticated = !isAuthenticated
print(isAuthenticated)

print(gameOver)
gameOver.toggle()
print(gameOver)

let firstPart = "Hello, "
let secondPart = "World!"
let greeting = firstPart + secondPart
print(greeting)

let people = "Haters"
let action = "hate"
let lyric = people + " gonna " + action
print(lyric)

let luggageCode = "1" + "2" + "3" + "4" + "5"
let name = "Taylor"
let age = 26
let message = "Hello my name is \(name) and I'm \(age) years old"


let number = 11
let missionMessage = "Applo \(number) landed on the moon."
print(missionMessage)


let celsius = -7
print("The weather today here is \(celsius) which is \(celsius  * 9 / 5 + 32) in Farhrenheit")
