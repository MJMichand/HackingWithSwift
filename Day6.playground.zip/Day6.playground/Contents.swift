import UIKit

var platforms = ["iOS", "macOS", "tvOS"]

for os in platforms {
    print("Swift works great on \(os)")
}

for i in 1...12 {
        print("The \(i) times table")
    
    for j in 1...12{
        print(" \(j) x \(i) is \(j * i)")
    }
    
}


for i in 1...5 {
    print("Counting 1 to 5: \(i)")
}
for i in 1..<5 {
    print("Counting 1 up to 5: \(i)")
}

var lyric = "Haters Gonna"

for _ in 1...5 {
    lyric += " hate"
}

print(lyric)


var countdown = 10

while countdown > 0 {
    print("\(countdown)")
    countdown -= 1
}
print("BLAST OFF!")


var id = Int.random(in: 1...1000)
print(id)

var amount = Double.random(in: 0...1)
print(amount)


var roll: Int = 0

while roll != 20 {
    roll = Int.random(in: 1...20)
    print("I rolled a \(roll)")
}
print("Critial HIT!")


var filenames = ["me.jpg", "work.txt", "sophie.jpg"]

for filename in filenames {
    if filename.hasSuffix(".jpg") == false {
        continue
    }
    
    print("Found picture \(filename)")
}


let number1 = 4
let number2 = 15
var multiples = [Int]()

for i in 1...100000 {
    if i.isMultiple(of: number1) && i.isMultiple(of: number2){
        multiples.append(i)
    }
       
}

//print(multiples)


var Fizz = "Fizz"
var Buzz = "Buzz"

for i in 1...100 {
    if i.isMultiple(of: 3) && i.isMultiple(of: 5) {
        print(Fizz, Buzz)
    } else if i.isMultiple(of: 3) {
        print(Fizz)
    } else if i.isMultiple(of: 5) {
        print(Buzz)
    } else {
        print(i)
    }
}
