import UIKit

func printTimesTable(number: Int, end: Int = 12)  {
    for i in 1...end {
        print("\(i) * \(number) is \(i  * number)")
    }
}
printTimesTable(number: 5)
var characters = ["Lana", "Pam", "Ray", "Stearling"]
print(characters.count)
characters.removeAll( keepingCapacity: true)
 

enum  PasswordError: Error {
    case short, obvious
}

func checkPassword(_ password: String) throws -> String {
    if password.count < 5 {
        throw PasswordError.short
    }
    if password == "12345" {
        throw PasswordError.obvious
    }
    if password.count < 8 {
        return "OK"
    } else if password.count < 10{
        return "Good"
    } else {
        return "Excellent"
    }
}
var string = "12345"

do {
    let result = try checkPassword(string)
    print("Password rating: \(result)")
} catch {
    print("There was an error.")
}

var i = 3
print(i * i)
sqrt(9)

enum RootError: Error {
    case tooLow, tooHigh, notFound
}

func squareRoot(of number: Int) throws -> Int {
    if number < 1 {
        throw RootError.tooLow
    }

    if number > 10_000 {
        throw RootError.tooHigh
    }

    for i in 1...100 {
        if i * i == number {
            return i
        }
    }
    
    throw  RootError.notFound
}

let number = 2112

do {
    let root = try squareRoot(of: number)
    print("The square root of \(number) is \(root).")
} catch {
    print("Sorry, there was a problem.")
}
