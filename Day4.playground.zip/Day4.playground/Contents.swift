import UIKit

var surname: String = "Lasso"
var score: Double = 0

var playerName: String = "Roy"
//var albums: [String] = ["Red", "Fearless"]


enum UIStyle {
    case light, dark, system
    }


var style: UIStyle = UIStyle.dark

UIStyle.system

/*Check point #2
 This time the challenge is to create an array of strings, then write some code that prints the number of items in the array and also the number of unique items in the array.
 */

var albums: [String] = ["Beginning", "University Street", "Love Songs", "Miss M", "Portrait", "Variety", "Love Songs", "Variety"]
print(albums.count)
var albumsSet = Set(albums)
print(albumsSet.count)

