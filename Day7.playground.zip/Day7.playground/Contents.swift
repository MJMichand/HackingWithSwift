import UIKit
func showWelcome() {
    print("Welcome to my app!")
}
showWelcome()


let number = 139

if number.isMultiple(of: 2) {
    print("even")
} else {
    print("Odd")
}


func printTimesTable(number: Int, end: Int) {
    for i in 1...end {
        print("\(i) * \(number) is \(i  * number)")
    }
}

printTimesTable(number: 5, end: 20)
let root = sqrt(169)
func rollDice() -> Int {
    return Int.random(in: 1...20)
}

var result = rollDice()
print(result)



func compareString(first: String, second: String) -> Bool {
     first.sorted() == second.sorted()
    
    
}

compareString(first: "abc", second: "cba")

func pythag(a: Double, b: Double) -> Double {
    sqrt(a * a + b * b)
}

let c = pythag(a: 3, b: 4)
print(c)


// returns can return nothing



func getUser() -> (firstName: String, lastName: String) {
    (firstName: "Taylor", lastName: "Swift")
}
 
let user = getUser()
print("Name: \(user.firstName) \(user.lastName)")

func rollDice(sides: Int, count: Int)  -> [Int] {
    var rolls = [Int]()
    
    for _ in 1...count {
        let roll  = Int.random(in: 1...sides)
        rolls.append(roll)
    }
    
    return rolls
}

let rolls = rollDice(sides: 6, count: 4)
print(rolls)


let lyric = "I see a red door and I want to paint it black"
print(lyric.hasPrefix("I see"))

func isUppercase(string: String) -> Bool {
    string == string.uppercased()
}


func printTimesTable(number: Int) {
    for i in 1...12 {
        print("\(i) x \(number) is \(i * number)")
        
    }
}

printTimesTable(number: 5)
