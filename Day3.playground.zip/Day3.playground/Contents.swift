import UIKit

var beatles = ["John", "Paul", "George", "Ringo"]

var numbers = [4,8,15,16,23,42]

var temps = [25.3, 28.2, 26.4]

beatles.append("Adrian")
beatles.append("Allen")

var score = Array<Int>()
score.append(100)
score.append(90)
score.append(80)
print(score[1])

var albums = [String]()
albums.append("Red")
albums.append("Folklore")
albums.append("Fearless")

var characters = ["Lana", "Pam", "Ray", "Sterling"]
print(characters.count)

characters.remove(at: 2)
print(characters.count)

characters.removeAll()
print(characters.count)

var bondMovies = ["Casio Royale", "Spectre", "No Time to Die"]
print(bondMovies.contains("Frozen"))

var cities = ["London", "Tokyo", "Rome", "Williamson"]
print(cities.sorted())

var presidents = ["Bush", "Obama", "Trump", "Biden"]
let revPres = presidents.reversed()
print(revPres)


var employee = ["Taylor Swift", "Singer", "Nashville"]

var employee2 = [
    "name": "Taylor Swift",
    "job": "Singer",
    "location": "Nashville"
]
print(employee2["name", default: "Unknown"])
print(employee2["job", default: "Unknown"])
print(employee2["location", default: "Unknown"])

var hasGraduated  = [
    "Eric": false,
    "Mayve": true,
    "Otis": false
]

var olympics = [
    2012: "London",
    2016: "Rio",
    2021: "Tokyo"
]
print(olympics[2012, default: "Unknown"])

var heights = [String : Int]()
heights["Yao Ming"] = 229
heights["Shaq"] = 216
heights["LeBron"] = 206

var archEnemies = [String: String]()
archEnemies["Batman"] = "The Joker"
archEnemies["Superman"] = "Lex"


var actors = Set([
    "Denzel Washington",
    "Tom Cruise",
    "Nick Cage",
    "Sam Jackson"
])
actors.insert("Nicole Kidman")
print(actors.count)

enum Weekday {
    case Monday
    case Tuesday
    case Wednesday
    case Thursday
    case Friday
}

var day = Weekday.Friday
