import UIKit

var greeting = "Hello Playground"

var name = "Ted"
name = "Rebecca"
name = "Keeley"

let chracter = "Daphne"
// character = "Eloise"

var playerName = "Roy"
print(playerName)
playerName = "Dani"
print(playerName)
playerName = "Sam"
print(playerName)

let managerName = "Michael Scott"
let dogBree = "Samoyed"
let meaningOfLife = "How many Roads must a man walk down?"
let actor = "Denzel Washington"
let filename = "paris.jpg"
let result = "⭐️ You win! ⭐️"
print(result)

let quote = "Then he tapped a sign saying \"Believe\" and walked away."
print(quote)

let movie = """
A day in
the life of an
Apple Engineer.
"""
print(movie)

print(actor.count)
print(result.uppercased())
print(movie.hasPrefix("A day"))
let score = 10
let reallyBig = 10000000
let lowerScore = score - 2
let higherScore = score  + 10
let doubledScore = score * 2
let suqaredScore = score * score
let halvedScore = score  / 2

var counter = 10
counter += 5
print(counter)

var number = 120
print(number.isMultiple(of: 3))
print(120.isMultiple(of: 3))

var numberD = 0.1 + 0.2
print(numberD)

let a = 1
let b = 2.0
let c = a + Int(b)
print(c)

var double1 = 3.1
var double2 = 3131.3131
var double3 = 3.0
var int1 = 3

name = "Nick Cage"
name = "Travolta"

var ratingD = 5.0
ratingD *= 2
print(ratingD)

