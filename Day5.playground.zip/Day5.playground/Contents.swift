import UIKit


var score = 85

if score > 80 {
    print("Great Job!")
}


var speed = 88
var percentage = 85
var age = 18

if speed >= 88 {
    print("Where we're going we don't need roads")
}

if percentage < 85 {
    print("Sorry you failed.")
}

if age >= 18 {
    print("You're able to vote.")
}

let ourName = ("Dave Lister")
let friendName = ("Arnold Rimmer")

if ourName < friendName {
    print("It's \(ourName) vs \(friendName)")
}

if ourName > friendName {
    print("It's \(friendName) vs \(ourName)")
}
var numbers = [1,2,3]
numbers.append(4)

if numbers.count > 3 {
    numbers.remove(at: 0)
}

print(numbers)

// ==
let country = "Canada"

if country == "Australia" {
    print("g'day!")
}

// !=
var name = "Taylor Swift"

if name != "Anon" {
    print("Welcome, \(name)")
}

var username = "taylorswift13"

if username.isEmpty {
    username = "Anon"
}

print("Welcome \(username)")


age = 16

if age >= 18 {
    print("You can vote.")
} else {
    print("You're too young to vote.")
}
var temp = 25

if temp > 20 && temp < 30 {
    print("It's a nice day out!")
}

var hasParentsPermission = true

if age >= 18 || hasParentsPermission == true {
    print("You can buy the game, scrub.")
}


enum transportOption {
    case airplane
    case helicopter
    case car
    case bicycle
    case escooter
}

var transport = transportOption.airplane

if transport == .airplane || transport == .helicopter {
    print("Time to fly!")
} else if transport == .bicycle {
    print("I hope there's a bike path!")
} else if  transport == .car {
    print("Time to get stuck in traffic")
} else {
    print("Time to book an escooter")
}


enum Weather {
    case sun, rain, wind, snow, unknown
}

let forecast = Weather.sun

if forecast == .sun {
    print("It should be a nice day.")
} else if forecast == .rain {
    print("Pack an umbrella.")
} else if forecast == .wind {
    print("Wear something warm")
} else if forecast == .rain {
    print("School is cancelled.")
} else {
    print("Our forecast generator is broken!")
}


age = 18

let canVote = age >= 18 ? "Yes" : "No"

 let hour = 23

print(hour < 12 ? "It's Aftternoon" : "It's afternoon.")

let names = ["Jayne", "Kaylee", "Mal"]
let crewCount = names.isEmpty ? "No One" : "\(names.count) people."
print(crewCount)
